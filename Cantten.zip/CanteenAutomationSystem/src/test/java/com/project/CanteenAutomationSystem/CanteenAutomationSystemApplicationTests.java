package com.project.CanteenAutomationSystem;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.project.CanteenAutomationSystem.Entity.OrderEntity;
import com.project.CanteenAutomationSystem.Exception.OrderAlreadyExistsException;
import com.project.CanteenAutomationSystem.Exception.OrderNotFondException;
import com.project.CanteenAutomationSystem.Service.OrderService;

@ExtendWith(MockitoExtension.class)
class CanteenAutomationSystemApplicationTests {

	@Mock
	OrderService orderService;

	@Test
	void addOrderTest() throws OrderAlreadyExistsException {
		LocalDate localDate = LocalDate.of( 2012 , 12 , 7 );
		OrderEntity orderEntity = new OrderEntity(1,"name1","phone airpodes powerbank","hyderabad",localDate);
		when(orderService.addOrder(orderEntity)).thenReturn(orderEntity);
		assertEquals(orderService.addOrder(orderEntity),orderEntity);
	}
	
	@Test
	void getOrderTest() throws OrderNotFondException {
		LocalDate localDate = LocalDate.of( 2012 , 12 , 7 );
		OrderEntity orderEntity = new OrderEntity(1,"name1","phone airpodes powerbank","hyderabad",localDate);
		Optional<OrderEntity> OOrderEntity = Optional.of(orderEntity);
		when(orderService.getOrder(1)).thenReturn(OOrderEntity);
		assertEquals(orderService.getOrder(1).get(),orderEntity);
	}
	
	@Test
	void updateOrderTest() throws OrderNotFondException {
		LocalDate localDate = LocalDate.of( 2012 , 12 , 7 );
		OrderEntity orderEntity = new OrderEntity(1,"name1","phone airpodes powerbank","hyderabad",localDate);
		when(orderService.updateOrder(1,orderEntity)).thenReturn(orderEntity);
		assertEquals(orderService.updateOrder(1,orderEntity),orderEntity);
	}
	
	@Test
	void deleteOrderTest() throws OrderNotFondException {
		LocalDate localDate = LocalDate.of( 2012 , 12 , 7 );
		OrderEntity orderEntity = new OrderEntity(1,"name1","phone airpodes powerbank","hyderabad",localDate);
		Optional<OrderEntity> OOrderEntity = Optional.of(orderEntity);
		when(orderService.deleteOrder(1)).thenReturn(OOrderEntity);
		assertEquals(orderService.deleteOrder(1).get(),orderEntity);
	}

}
