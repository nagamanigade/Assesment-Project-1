package com.project.CanteenAutomationSystem.Exception;

public class OrderInvalidCredentialsException extends RuntimeException{
	
	public OrderInvalidCredentialsException(String msg) {
		super(msg);
	}

}
