package com.project.CanteenAutomationSystem.ServiceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.CanteenAutomationSystem.DAO.IAddressRepository;
import com.project.CanteenAutomationSystem.Entity.Address;
import com.project.CanteenAutomationSystem.Service.IAddressService;

@Service
public class AddressServiceImpl implements IAddressService {
	@Autowired
	IAddressRepository addRepo;

	@Override
	public List<Address> getAllAddresses() {

		return addRepo.findAll();
	}

	@Override
	public Address deleteAddress(int addrId) {

		// find address based on address id
		Optional<Address> addr = addRepo.findById(addrId);

		// delete address if present else return null
		if (addr.isPresent()) {
			addRepo.deleteById(addrId);
		} else {
			return null;
		}
		// return address
		return addr.get();
	}

}
