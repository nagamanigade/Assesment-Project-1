package com.project.CanteenAutomationSystem.Exception;

public class EmailNotFoundException extends Exception {
	
	public EmailNotFoundException(String message) {
		super(message);
	}

}
