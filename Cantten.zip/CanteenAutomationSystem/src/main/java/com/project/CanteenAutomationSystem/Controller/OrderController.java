package com.project.CanteenAutomationSystem.Controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;   
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.project.CanteenAutomationSystem.Entity.OrderEntity;
import com.project.CanteenAutomationSystem.Exception.OrderAlreadyExistsException;
import com.project.CanteenAutomationSystem.Exception.OrderNotFondException;
import com.project.CanteenAutomationSystem.Service.OrderService;
@CrossOrigin(origins = "http://localhost:3000")
@RestController
public class OrderController {

	@Autowired
	private OrderService orderService;
	
//get all orders details
	@GetMapping("/order")
	public List<OrderEntity> getAllOrders(){
		return orderService.getAllOrders();
	}
	
	// get order details by id 
	
	@GetMapping("/order/{id}")
	public Optional<OrderEntity> getOrder(@PathVariable int id) throws OrderNotFondException{
		return orderService.getOrder(id);
	}
	
	// add order details
	@PostMapping("/order")
	public OrderEntity addOrder(@Valid @RequestBody OrderEntity  orderEntity) throws OrderAlreadyExistsException{
		return orderService.addOrder(orderEntity);
	}
	// delete order details by id
	@DeleteMapping("/order/{id}")
	public Optional  <OrderEntity> deleteOrder(@PathVariable int id) throws OrderNotFondException{
		return orderService.deleteOrder(id);
	}
    // update order details by id
	@PutMapping("/order/{id}")
	public OrderEntity updateOrder(@PathVariable int id, @Valid @RequestBody OrderEntity orderEntity) throws OrderNotFondException{
		return orderService.updateOrder(id, orderEntity);
	}

}
