package com.project.CanteenAutomationSystem.Service;

import java.util.List;

import com.project.CanteenAutomationSystem.Entity.Address;

public interface IAddressService {
	
	List<Address> getAllAddresses();

	Address deleteAddress(int addrId);

}
