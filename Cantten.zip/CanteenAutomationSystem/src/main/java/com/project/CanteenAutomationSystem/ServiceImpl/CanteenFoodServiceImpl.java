package com.project.CanteenAutomationSystem.ServiceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.CanteenAutomationSystem.Exception.CanteenFoodNotFoundException;
import com.project.CanteenAutomationSystem.Service.ICanteenFoodService;

import com.project.CanteenAutomationSystem.Entity.CanteenFood;

@Service
public class CanteenFoodServiceImpl implements ICanteenFoodService{

	@Override
	public CanteenFood add(CanteenFood id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<CanteenFood> getAllCanteenFood() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public CanteenFood getCanteenById(int foodId) throws CanteenFoodNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public CanteenFood deleteCanteenFood(int foodId) throws CanteenFoodNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public CanteenFood updateFoodQuantity(int foodId, int foodQuantity) throws CanteenFoodNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public CanteenFood saveCanteenFood(CanteenFood foodId) {
		// TODO Auto-generated method stub
		return null;
	}
	
	

	
	
 }
