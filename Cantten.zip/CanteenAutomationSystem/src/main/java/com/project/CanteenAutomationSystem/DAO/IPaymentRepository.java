package com.project.CanteenAutomationSystem.DAO;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.CanteenAutomationSystem.Entity.Payment;

public interface IPaymentRepository extends JpaRepository<Payment, Integer> {
	
	//Custom query methods
		List<Payment> findByPaymentId(int PaymentId);
		List<Payment> findByTotalPayment(double Payment);
		List<Payment> findByPaymentType(String PaymentType);

}
