package com.project.CanteenAutomationSystem.Exception;

public class CartNotFoundException extends Exception {

	
	public CartNotFoundException(String message) {
		super(message);
		
	}
}
