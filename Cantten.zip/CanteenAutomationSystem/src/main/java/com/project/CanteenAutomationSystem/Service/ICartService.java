package com.project.CanteenAutomationSystem.Service;

import java.util.List;

import com.project.CanteenAutomationSystem.Entity.Cart;
import com.project.CanteenAutomationSystem.Exception.CartNotFoundException;

public interface ICartService {
	
	List<Cart> getAllCartItems();

	Cart updateItemById(Cart cart, int cartId);

	Cart deleteItem(int cartId) throws CartNotFoundException;

	Cart updateCartPrice(int cartId, int cartTotal) throws CartNotFoundException;

	Cart addItemToCart(Cart foodItem) throws CartNotFoundException;

	// Cart updateItemId(int cartId, int itemId);
	Cart getCartById(int cartId) throws CartNotFoundException;

}
