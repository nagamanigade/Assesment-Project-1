package com.project.CanteenAutomationSystem.Service;

import java.util.List;

import com.project.CanteenAutomationSystem.Entity.CanteenFood;
import com.project.CanteenAutomationSystem.Exception.CanteenFoodNotFoundException;

public interface ICanteenFoodService {
	
	CanteenFood add(CanteenFood id);

	List<CanteenFood> getAllCanteenFood();

	CanteenFood getCanteenById(int foodId) throws CanteenFoodNotFoundException ;
	
	CanteenFood deleteCanteenFood(int foodId) throws CanteenFoodNotFoundException ;

	CanteenFood updateFoodQuantity(int foodId, int foodQuantity) throws CanteenFoodNotFoundException ;

	CanteenFood saveCanteenFood(CanteenFood foodId);

}
