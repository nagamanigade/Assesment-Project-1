package com.project.CanteenAutomationSystem.DAO;

public interface ICanteenFoodRepository {

}
