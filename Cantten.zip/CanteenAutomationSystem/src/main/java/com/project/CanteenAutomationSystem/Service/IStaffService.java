package com.project.CanteenAutomationSystem.Service;

import com.project.CanteenAutomationSystem.Entity.Staff;
import com.project.CanteenAutomationSystem.Exception.StaffNotFoundException;

public interface IStaffService {
	Staff addStaff(Staff staff);

	Staff deleteStaff(int staffId) throws StaffNotFoundException;
    Staff getStaffById(int staffId)throws StaffNotFoundException;

	Staff updateStaff(int staffId, String staffname)throws StaffNotFoundException;
}
