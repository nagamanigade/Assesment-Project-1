package com.project.CanteenAutomationSystem.Exception;



public class PaymentNotFoundException extends Exception{
	public PaymentNotFoundException(String message) {
		super(message);

	}
	

}
