package com.project.CanteenAutomationSystem.Exception;

public class CustomerFoundException extends Exception {
	
	public CustomerFoundException(String message) {
		super(message);
	}

}
