package com.project.CanteenAutomationSystem.Exception;

public class StaffNotFoundException extends Exception {
	
	public StaffNotFoundException(String message) {
		super(message);
	
	}

}
